import React, { useEffect, useState } from "react";
import axios from "axios";

const App = () => {
  const [odds, setOdds] = useState([]);
  const [stats, setStats] = useState(null);
  const [rivalry, setRivalry] = useState(null);
  const [draft, setDraft] = useState([]);
  const [league, setLeague] = useState("basketball_nba");
  const [player1, setPlayer1] = useState("LeBron James");
  const [player2, setPlayer2] = useState("Stephen Curry");

  useEffect(() => {
    const ws = new WebSocket(`ws://localhost:8000/ws/odds?league=${league}`);
    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (!data.error) {
          setOdds(data);
        }
      } catch (e) {
        console.error("Failed to parse WebSocket message:", e);
      }
    };
    return () => ws.close();
  }, [league]);

  const getStats = async () => {
    const res = await axios.get(`http://localhost:8000/player_stats?name=${player1}&league=${league}`);
    setStats(res.data);
  };

  const getRivalry = async () => {
    const res = await axios.get(`http://localhost:8000/rivalry?player1=${player1}&player2=${player2}&league=${league}`);
    setRivalry(res.data);
  };

  const getDraft = async () => {
    const res = await axios.get(`http://localhost:8000/draft_movement?league=${league}`);
    setDraft(res.data);
  };

  return (
    <div className="p-4 text-white bg-gray-900 min-h-screen">
      <h1 className="text-3xl font-bold mb-4">NBA/WNBA Odds Tracker</h1>

      <div className="mb-4">
        <label className="mr-2">League:</label>
        <select value={league} onChange={(e) => setLeague(e.target.value)} className="text-black">
          <option value="basketball_nba">NBA</option>
          <option value="basketball_wnba">WNBA</option>
        </select>
      </div>

      <div className="mb-4">
        <h2 className="text-xl font-semibold">Live Odds</h2>
        <ul className="mt-2">
          {Array.isArray(odds) && odds.length > 0 ? odds.map((game, i) => (
            <li key={i}>
              {game.bookmakers?.[0]?.markets?.[0]?.outcomes?.map(outcome => (
                <span key={outcome.name}>{outcome.name}: {outcome.price} | </span>
              ))}
            </li>
          )) : <li>No data</li>}
        </ul>
      </div>

      <div className="mb-4">
        <h2 className="text-xl font-semibold">Player Stats</h2>
        <input value={player1} onChange={e => setPlayer1(e.target.value)} className="text-black mr-2" />
        <button onClick={getStats} className="bg-blue-500 px-2 py-1 rounded">Get Stats</button>
        {stats && <div className="mt-2">{stats.name} ({stats.team}) - {stats.ppg} PPG, {stats.apg} APG, {stats.rpg} RPG</div>}
      </div>

      <div className="mb-4">
        <h2 className="text-xl font-semibold">Rivalry</h2>
        <input value={player1} onChange={e => setPlayer1(e.target.value)} className="text-black mr-2" />
        <input value={player2} onChange={e => setPlayer2(e.target.value)} className="text-black mr-2" />
        <button onClick={getRivalry} className="bg-purple-500 px-2 py-1 rounded">Compare</button>
        {rivalry && <div className="mt-2">{rivalry.player1} ({rivalry.player1_wins}) vs {rivalry.player2} ({rivalry.player2_wins}) in {rivalry.meetings} meetings</div>}
      </div>

      <div className="mb-4">
        <h2 className="text-xl font-semibold">Draft Movement</h2>
        <button onClick={getDraft} className="bg-green-500 px-2 py-1 rounded">Fetch Draft</button>
        <ul className="mt-2">
          {draft.map((d, i) => (
            <li key={i}>{d.player} moved from #{d.from} to #{d.to} ({d.change})</li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default App;
