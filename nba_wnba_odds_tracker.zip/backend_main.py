# backend_main.py
from fastapi import FastAPI, WebSocket, Query
from fastapi.middleware.cors import CORSMiddleware
import httpx, os
from dotenv import load_dotenv

load_dotenv()
app = FastAPI()

origins = ["http://localhost:3000", "*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

ODDS_API_KEY = os.getenv("ODDS_API_KEY", "demo")

@app.websocket("/ws/odds")
async def websocket_odds(websocket: WebSocket, league: str = Query(...)):
    await websocket.accept()
    async with httpx.AsyncClient() as client:
        while True:
            try:
                r = await client.get(f"https://api.the-odds-api.com/v4/sports/{league}/odds/?apiKey={ODDS_API_KEY}&regions=us&markets=h2h")
                await websocket.send_json(r.json())
            except Exception as e:
                await websocket.send_json({"error": str(e)})
                break

@app.get("/player_stats")
async def player_stats(name: str, league: str):
    return {"name": name, "season": "2024", "team": "Example Team", "ppg": 22.5, "apg": 5.4, "rpg": 7.1}

@app.get("/rivalry")
async def rivalry(player1: str, player2: str, league: str):
    return {"player1": player1, "player2": player2, "player1_wins": 5, "player2_wins": 3, "meetings": 8}

@app.get("/draft_movement")
async def draft_movement(league: str):
    return [
        {"player": "John Doe", "from": 10, "to": 5, "change": "+5"},
        {"player": "Jane Smith", "from": 3, "to": 7, "change": "-4"}
    ]
